//
//  AppDelegate.swift
//  picApp
//
//  Created by Jeferson Montanha on 01/05/16.
//  Copyright © 2016 Jeferson Montanha. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
       /*
        NSUserDefaults.standardUserDefaults().registerDefaults(["PhotoFeedURLString": "https://api.flickr.com/services/feeds/photos_public.gne?tags=pug&format=json&nojsoncallback=1"])
        */
        return true
    }


    func applicationDidBecomeActive(application: UIApplication) {

        /*
        let urlString = NSUserDefaults.standardUserDefaults().stringForKey("PhotoFeedURLString")
        print(urlString)
        
        guard let foundURLString = urlString else {
            return
        }
        
        if let url = NSURL(string: foundURLString) {
            self.updateFeed(url, completion: { (feed) -> Void in
                let viewController = application.windows[0].rootViewController as? ViewController
                viewController?.feed = feed
                //print(feed?.items.count)
            })
        }
*/
        
    }
    

    func applicationWillTerminate(application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }

}

