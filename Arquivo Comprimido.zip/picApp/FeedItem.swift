//
//  FeedItem.swift
//  picApp
//
//  Created by Jeferson Montanha on 10/05/16.
//  Copyright © 2016 Jeferson Montanha. All rights reserved.
//

import Foundation


struct FeedItem{
    let title: String
    let imageURL: NSURL
}