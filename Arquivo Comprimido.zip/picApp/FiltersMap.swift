//
//  File.swift
//  picApp
//
//  Created by Jeferson Montanha on 17/05/16.
//  Copyright © 2016 Jeferson Montanha. All rights reserved.
//

import Foundation

public enum FiltersMap: String {
    case RedOne
    case GreenOne
    case BlueOne
    case brightness
    case alpha
    case blank
}